
Versions of the project are provided in one file each.

Compile with gcc filename -std=99

Original files:

at4.c - This is the first version that works
hybrid2.fast.c - This is a more readable format of the code, although it runs with some bugs

These files were used for the timing tests, with optimisations hardcoded:

at5.0.c - This has ONLY branch and bound
at5.1.c - Branch and bound and reduction #1 (single freqency elements)
at5.2.c - Reduction #1 and #2/#3 (remove subsets)
at5.3.c - Reduction #1 and #2/#3, and measure-and-conquer recursively


